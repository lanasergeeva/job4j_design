# job4j_design 

[![Build Status](https://www.travis-ci.com/lanasergeeva/job4j_design.svg?branch=master)](https://www.travis-ci.com/lanasergeeva/job4j_design)

[![codecov](https://codecov.io/gh/lanasergeeva/job4j_design/branch/master/graph/badge.svg?token=M78WB0H6C8)](https://codecov.io/gh/lanasergeeva/job4j_design)